//
//  ContentView.swift
//  PitchPerfect
//
//  Created by Alex Pricope on 20/04/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
